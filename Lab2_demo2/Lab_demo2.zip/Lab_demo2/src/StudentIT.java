public class StudentIT extends Student{
    private final double javaScore;
    private final double cssScore;

    public StudentIT(String id, String fullName, Address address, double javaScore, double cssScore) {
        super(id, fullName, address, javaScore,cssScore);
        this.javaScore = javaScore;
        this.cssScore = cssScore;
    }

    @Override
    public double getGpa() {
        return avgGpa();
    }

    @Override
    void setGpa(double gpa) {

    }

    @Override
    public String show() {
        return " [STUDENT IT] "
                + "ID: " + getId()
                + ", FULL NAME: " + getFullName()
                + ", JAVA SCORE: " + javaScore
                + ", CSS SCORE: " + cssScore
                + ", GPA: " + getGpa()
                + ", ADDRESS: " + getAddress();
    }

    @Override
    double avgGpa() {
        return (3 * javaScore + cssScore) / 4;
    }

    @Override
    public int compareTo(Student o) {
        return this.getFullName().compareTo(o.getFullName());
    }
}
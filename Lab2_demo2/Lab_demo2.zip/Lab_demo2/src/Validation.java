import java.util.Scanner;

public class Validation {
    static Scanner sc = new Scanner(System.in);

    public static String inputString(String string) {
        Scanner in = new Scanner(System.in);
        while (true) {
            System.out.print(string);
            String str = in.nextLine();
            if (!str.isEmpty()) {
                return str;
            } else {
                System.out.println("String cannot be empty!");
            }
        }
    }

    public static int inputInteger(String string) {
        Scanner in = new Scanner(System.in);
        int n = 0;
        while (true) {
            try {
                System.out.print(string);
                n = Integer.parseInt(in.nextLine());
                return n;
            } catch (Exception e) {
                System.out.println("Required positive integer!");
            }
        }
    }

    public static double inputDouble(String string) {
        Scanner in = new Scanner(System.in);
        double n = 0;
        while (true) {
            try {
                System.out.print(string);
                n = Double.parseDouble(in.nextLine());
                return n;
            } catch (Exception e) {
                System.out.println("Required positive integer!");
            }
        }
    }
    public static int inputSelect(String mess, int min, int max) {
        System.out.print(mess);
        while(true) {
            String input = sc.nextLine();
            try {
                int number = Integer.parseInt(input);
                //check range of number
                if (number < min || number > max) {
                    System.out.print("Please input between " + min + ", " + max + ": ");
                    continue;
                }
                return number;
            } catch (Exception e) {
                System.out.print("Please input an integer number: ");
            }
        }
    }

    public static boolean checkInputUD() {
        while (true) {
            String result = inputString("Select U/update or D/delete: ");
            if (result.equalsIgnoreCase("U")) {
                return true;
            }
            if (result.equalsIgnoreCase("D")) {
                return false;
            }
            System.err.println("Please input u/U or d/D.");
            System.out.print("Enter again: ");
        }
    }


}
